<div>
    {{-- Stop trying to control. --}}
    Form livewire
    {{json_encode($handovers)}}
</div>
