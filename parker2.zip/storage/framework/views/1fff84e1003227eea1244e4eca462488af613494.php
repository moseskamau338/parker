<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php echo $__env->make('layouts.includes.breadcrumb', ['crumbs'=>[
            (object)['name' => 'Zones', 'route'=>'zones'],
            (object)['name' => 'View: '.ucwords($zone->name), 'route'=>'zones'],
        ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 p-2">
              <!-- Stats -->
            <div>
              <h3 class="text-lg leading-6 font-medium text-gray-900">
                Site Stats
              </h3>
              <dl class="mt-3 mb-4 grid grid-cols-1 gap-5 sm:grid-cols-5">
                <div class="px-2 py-2 bg-white shadow rounded-lg overflow-hidden sm:p-3">
                  <dt class="text-sm font-medium text-gray-500 truncate">
                    Total Sales
                  </dt>
                  <dd class="mt-1 text-3xl font-semibold text-gray-900">
                      <?php echo e($zone->sales->count() ?? 0); ?>

                  </dd>
                </div>

                <div class="px-2 py-2 bg-white shadow rounded-lg overflow-hidden sm:p-3">
                  <dt class="text-sm font-medium text-gray-500 truncate">
                    Users Registered
                  </dt>
                  <dd class="mt-1 text-3xl font-semibold text-gray-900">
                      <?php echo e($zone->users->count() ?? 0); ?>

                  </dd>
                </div>

                <div class="px-2 py-2 bg-white shadow rounded-lg overflow-hidden sm:p-3">
                  <dt class="text-sm font-medium text-gray-500 truncate">
                    All Shifts
                  </dt>
                  <dd class="mt-1 text-3xl font-semibold text-gray-900">
                      <?php echo e($zone->shifts->count() ?? 0); ?>

                  </dd>
                </div>
              </dl>
            </div>

            <h2 class="text-2xl text-gray-700 font-bold mb-4">Details for zone: <?php echo e(Str::of($zone->name)->title()); ?></h2>

            <h2 class="text-2xl text-gray-500 font-semibold">Users</h2>
            <!-- This example requires Tailwind CSS v2.0+ -->
            <div class="flex flex-col mt-2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('zone-users-table', ['zone'=>$zone])->html();
} elseif ($_instance->childHasBeenRendered('ULE9WNV')) {
    $componentId = $_instance->getRenderedChildComponentId('ULE9WNV');
    $componentTag = $_instance->getRenderedChildComponentTagName('ULE9WNV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ULE9WNV');
} else {
    $response = \Livewire\Livewire::mount('zone-users-table', ['zone'=>$zone]);
    $html = $response->html();
    $_instance->logRenderedChild('ULE9WNV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>

             <h2 class="text-2xl mt-5 text-gray-500 font-semibold">Shift Handovers</h2>
            <!-- This example requires Tailwind CSS v2.0+ -->
            <div class="flex flex-col mt-2">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('zone-shifts-table', ['zone'=>$zone])->html();
} elseif ($_instance->childHasBeenRendered('iP1R7B8')) {
    $componentId = $_instance->getRenderedChildComponentId('iP1R7B8');
    $componentTag = $_instance->getRenderedChildComponentTagName('iP1R7B8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iP1R7B8');
} else {
    $response = \Livewire\Livewire::mount('zone-shifts-table', ['zone'=>$zone]);
    $html = $response->html();
    $_instance->logRenderedChild('iP1R7B8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /root/code/playground/parker/resources/views/zones/show.blade.php ENDPATH**/ ?>