<div>
    
    Form livewire
    <?php echo e(json_encode($handovers)); ?>

</div>
<?php /**PATH /root/code/playground/parker/resources/views/livewire/shifts/handovers.blade.php ENDPATH**/ ?>