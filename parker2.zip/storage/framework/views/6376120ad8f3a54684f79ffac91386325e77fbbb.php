<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <?php echo $__env->make('layouts.includes.breadcrumb', ['crumbs'=>[
        (object)['name' => 'Zones', 'route'=>'zones'],
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 p-2">
            <h1 class="text-2xl text-gray-700">Manage <strong>Zones</strong></h1>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('zones')->html();
} elseif ($_instance->childHasBeenRendered('nS6jXtj')) {
    $componentId = $_instance->getRenderedChildComponentId('nS6jXtj');
    $componentTag = $_instance->getRenderedChildComponentTagName('nS6jXtj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nS6jXtj');
} else {
    $response = \Livewire\Livewire::mount('zones');
    $html = $response->html();
    $_instance->logRenderedChild('nS6jXtj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /root/code/playground/parker/resources/views/zones/index.blade.php ENDPATH**/ ?>