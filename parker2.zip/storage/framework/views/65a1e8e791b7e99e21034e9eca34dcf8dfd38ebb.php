<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts.includes.breadcrumb', ['crumbs'=>[
        (object)['name' => 'Reports', 'route'=>'reports'],
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 p-2">
             <h2 class="text-2xl mt-5 text-gray-500 font-semibold">Banking Report</h2>
            <!-- This example requires Tailwind CSS v2.0+ -->
            <div class="flex flex-col mt-2">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('banking-report-table')->html();
} elseif ($_instance->childHasBeenRendered('y5jSx9n')) {
    $componentId = $_instance->getRenderedChildComponentId('y5jSx9n');
    $componentTag = $_instance->getRenderedChildComponentTagName('y5jSx9n');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('y5jSx9n');
} else {
    $response = \Livewire\Livewire::mount('banking-report-table');
    $html = $response->html();
    $_instance->logRenderedChild('y5jSx9n', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /root/code/playground/parker/resources/views/reports/index.blade.php ENDPATH**/ ?>