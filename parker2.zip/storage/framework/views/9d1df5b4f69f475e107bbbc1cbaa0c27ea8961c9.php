<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <?php echo $__env->make('layouts.includes.breadcrumb', ['crumbs'=>[
        (object)['name' => 'Sales', 'route'=>'sales'],
        (object)['name' => 'Handovers', 'route'=>'sales.handovers'],
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 p-2">
            <div class="flex justify-end mb-4">
                <a href="<?php echo e(route('receipts')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium
                rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Record Bank Receipts
                </a>
            </div>
            <div style="overflow-x: auto">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sales-handover-table')->html();
} elseif ($_instance->childHasBeenRendered('lC1bRJy')) {
    $componentId = $_instance->getRenderedChildComponentId('lC1bRJy');
    $componentTag = $_instance->getRenderedChildComponentTagName('lC1bRJy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lC1bRJy');
} else {
    $response = \Livewire\Livewire::mount('sales-handover-table');
    $html = $response->html();
    $_instance->logRenderedChild('lC1bRJy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /root/code/playground/parker/resources/views/sales/handovers.blade.php ENDPATH**/ ?>