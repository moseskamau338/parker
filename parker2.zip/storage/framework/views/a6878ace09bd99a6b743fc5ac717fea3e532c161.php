<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <?php echo $__env->make('layouts.includes.breadcrumb', ['crumbs'=>[
        (object)['name' => 'View Shifts', 'route'=>'users'],
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-4 lg:px-6 p-2">
            <div class="mb-4 flex justify-end">
                <a href="<?php echo e(route('shifts.handovers')); ?>" class="inline-flex items-center px-2.5 py-1.5 border border-gray-300 shadow-sm text-xs
                font-medium
                rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                  View Handover
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                </a>
            </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('shift-table')->html();
} elseif ($_instance->childHasBeenRendered('h0aqC5v')) {
    $componentId = $_instance->getRenderedChildComponentId('h0aqC5v');
    $componentTag = $_instance->getRenderedChildComponentTagName('h0aqC5v');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h0aqC5v');
} else {
    $response = \Livewire\Livewire::mount('shift-table');
    $html = $response->html();
    $_instance->logRenderedChild('h0aqC5v', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /root/code/playground/parker/resources/views/shifts/index.blade.php ENDPATH**/ ?>