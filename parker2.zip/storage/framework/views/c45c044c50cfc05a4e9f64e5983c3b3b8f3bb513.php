<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php echo $__env->make('layouts.includes.breadcrumb', ['crumbs'=>[
        (object)['name' => 'Shift Handovers', 'route'=>'shifts.handovers'],
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 p-2">
            <h3 class="text-gray-700 text-2xl font-bold">Shift Handovers:</h3>
            <div class="mb-4 flex justify-end">
            <a href="<?php echo e(route('shifts.view')); ?>" class="inline-flex items-center px-2.5 py-1.5 border border-gray-300 shadow-sm text-xs
            font-medium
            rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16l-4-4m0 0l4-4m-4 4h18" />
                </svg>

              View Shifts
            </a>
        </div>
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('handover-table')->html();
} elseif ($_instance->childHasBeenRendered('UfSsBnJ')) {
    $componentId = $_instance->getRenderedChildComponentId('UfSsBnJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('UfSsBnJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UfSsBnJ');
} else {
    $response = \Livewire\Livewire::mount('handover-table');
    $html = $response->html();
    $_instance->logRenderedChild('UfSsBnJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /root/code/playground/parker/resources/views/shifts/handovers.blade.php ENDPATH**/ ?>