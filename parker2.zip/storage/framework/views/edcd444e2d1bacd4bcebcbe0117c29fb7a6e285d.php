<div>
    <?php if($dumpFilters): ?>
        <?php dump($filters); ?>
    <?php endif; ?>
</div>
<?php /**PATH /root/code/playground/parker/vendor/rappasoft/laravel-livewire-tables/src/../resources/views/includes/debug.blade.php ENDPATH**/ ?>